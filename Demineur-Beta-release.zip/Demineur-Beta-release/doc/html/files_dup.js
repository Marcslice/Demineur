var files_dup =
[
    [ "AITest.cs", "_a_i_test_8cs.html", [
      [ "AITest", "class_demineur_1_1_a_i_test.html", "class_demineur_1_1_a_i_test" ]
    ] ],
    [ "Case.cs", "_case_8cs.html", [
      [ "Case", "class_demineur_1_1_case.html", "class_demineur_1_1_case" ]
    ] ],
    [ "Classements.cs", "_classements_8cs.html", [
      [ "Classements", "class_demineur_1_1_classements.html", "class_demineur_1_1_classements" ]
    ] ],
    [ "Demineur.cs", "_demineur_8cs.html", [
      [ "Demineur", "class_demineur_1_1_demineur.html", "class_demineur_1_1_demineur" ]
    ] ],
    [ "Grille.cs", "_grille_8cs.html", [
      [ "Grille", "class_demineur_1_1_grille.html", "class_demineur_1_1_grille" ]
    ] ],
    [ "IA.cs", "_i_a_8cs.html", [
      [ "IA", "class_demineur_1_1_i_a.html", "class_demineur_1_1_i_a" ]
    ] ],
    [ "InterfaceUsager.cs", "_interface_usager_8cs.html", [
      [ "InterfaceUsager", "class_demineur_1_1_interface_usager.html", "class_demineur_1_1_interface_usager" ]
    ] ],
    [ "Joueur.cs", "_joueur_8cs.html", [
      [ "Joueur", "class_demineur_1_1_joueur.html", "class_demineur_1_1_joueur" ]
    ] ],
    [ "Menu.cs", "_menu_8cs.html", [
      [ "Menu", "class_demineur_1_1_menu.html", "class_demineur_1_1_menu" ]
    ] ],
    [ "Partie.cs", "_partie_8cs.html", [
      [ "Partie", "class_demineur_1_1_partie.html", "class_demineur_1_1_partie" ]
    ] ]
];