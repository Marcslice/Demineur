var indexSectionsWithContent =
{
  0: "abcdefgijlmnoprstv",
  1: "acdgijmp",
  2: "d",
  3: "acdgijmp",
  4: "abcdefgijlmoprstv",
  5: "abcdegilmnoprst",
  6: "bnostv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Propriétés"
};

